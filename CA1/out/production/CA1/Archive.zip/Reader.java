public class Reader extends Thread {

    private String readerName;

    public Reader(String name) {
        super(name);
        readerName = name;
    }

    @Override
    public void run() {
        while (Buffer.var < Buffer.MAX){
            try {
                Thread.sleep(500);
                Buffer.readerSemaphore.acquire();

                if (Buffer.readerSemaphore.availablePermits() == 1)
                    System.out.println("The first reader acquires the lock.");

                if (readerName.equals("Reader1"))
                    System.out.println("Reader1 reads the value " + Buffer.var + ".");
                else
                    System.out.println("Reader2 reads the value " + Buffer.var + ".");

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Buffer.readerSemaphore.release();

            if (Buffer.readerSemaphore.availablePermits() == 2)
                System.out.println("The last reader releases the lock.");
        }
    }
}